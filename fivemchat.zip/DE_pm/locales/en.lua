Locales['en'] = {
    -- Sending and Receiving
    ['pm_send'] = 'PM sent to',
    ['pm_receive'] = 'PM from',
    -- Help
    ['pm'] = 'PM to user',
    ['id'] = 'ID of receiver',
    ['msg'] = 'Message',
    -- Chyby
    ['wrong_id'] = 'Wrong ID!',
    ['self_pm'] = "You can't send PM to yourself!",
    ['wrong_usage'] = 'Wrong ID / Message',
    -- Webhook
    ['message'] = 'Message',
    ['pm_sent_to'] = 'Sent PM to',
  }