Config        = {}

Config.Locale = 'en'
Config.Logging = true
Config.Webhook = 'DISCORD_WEBHOOK_HERE'