fx_version 'adamant'
game 'gta5' 
author 'Delarmuss'
version '1.2'
client_scripts {
	'client.lua'
}
ui_page "ui/ui.html"
files {
	"ui/css/*.css",
	"ui/js/*.js",
	"ui/sounds/*.ogg",
	"ui/ui.html"
}   
exports {
	'SendAlert'
}