Locales['cs'] = {
    -- Odesílání a přijímání PM
    ['pm_send'] = 'Odeslal jste PM hráči',
    ['pm_receive'] = 'Obdržel jste PM od hráče',
    -- Help
    ['pm'] = 'PM hráči',
    ['id'] = 'ID hráče',
    ['msg'] = 'Zpráva',
    -- Chyby
    ['wrong_id'] = 'Neplatné ID!',
    ['self_pm'] = 'Nemůžete poslat PM sám sobě!',
    ['wrong_usage'] = 'Chybné zadání',
    -- Webhook
    ['message'] = 'Zpráva',
    ['pm_sent_to'] = 'Zaslal PM hráči'
  }
  