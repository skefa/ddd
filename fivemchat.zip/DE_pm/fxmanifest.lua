fx_version 'adamant'
game 'gta5'

author 'DimeloEli'

lua54 'yes'

server_scripts {
  '@es_extended/locale.lua',
  'locales/cs.lua',	
  'locales/en.lua',	
  'config.lua',
  'server.lua'
}

escrow_ignore {
  'config.lua'
}